<?php

namespace App\Http\Controllers\Users\Lens;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CasePrescriptionsController extends Controller
{
    //
    public function __construct()
    {
        
    }
}
