<?php

namespace App\Exports\Admin\Reports;

use Maatwebsite\Excel\Concerns\FromCollection;

class TATOneReport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
