<?php 

return [
    'app_version' => '1.0.0'
];